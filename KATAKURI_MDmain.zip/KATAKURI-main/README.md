#KATAKURI_MD
  
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=910&height=100&lines=THANKS FOR ARISING +KATAKURI_MD;MULTI+DEVICE+WHATSAPP+BOT;ARISED+BY+KATAKURI." alt="Typing SVG" /></a>
  </p>
    <img alt="KATAKURI_MD" width="700" height="300" src="">
<p align="center">
<p align="center">
<a href="https://github.com/boru-to/KATAKURI_MD"><img title="Author" src="https://img.shields.io/badge/KATAKURI_MD-black?style=for-the-badge&logo=github"></a>
<p/>
<p align="center">
<a href="https://github.com/boru-to?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/franceking1?label=Followers&style=social"></a>
<a href="https://github.com/boru-to/KATAKURI_MD/stargazers/"><img title="STARS" src="https://img.shields.io/github/stars/boru-to/KATAKURI_MD?&style=social"></a>
 
## KATAKURI_MD Deployment Methods

### 1. FORK THIS REPO

<a href="https://github.com/boru-to/KATAKURI_MD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/boru-to/KATAKURI_MD?style=social"></a>
<a href="https://github.com/boru-to/KATAKURI_MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/boru-to/KATAKURI_MD?label=Watching&style=social"></a>

### 2. GET SESSION ID HERE
 
<a href="https://apppp-4a1971b28792.herokuapp.com/pair"><img src="https://img.shields.io/badge/PAIR_CODE-blue" alt="Click Here to Get Pair-Code" width="110"></a>   

<a href="https://arthur-scanner.onrender.com/qr"><img src="https://img.shields.io/badge/QR CODE-green" alt="Click Here to Get QR-Code" width="90"></a>


### DEPLOY ON RENDER

1. If you don't have an account in RENDER, create one and deploy.
    <br>
    <a href='https://dashboard.render.com/select-repo?type=web' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=render&logoColor=white'/></a>


### DEPLOY ON CLEVER CLOUD

1. If you don't have an account in Clever Cloud, create one and deploy.
    <br>
    <a href='https://api.clever-cloud.com/v2/sessions/signup?subscription_source=cta-home-signup' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-orange?style=for-the-badge&logo=clever-cloud&logoColor=white'/></a>

### DEPLOY ON HEROKU

1. If you don't have an account in Heroku, create one.
    <br>
    <a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-purple?style=for-the-badge&logo=heroku&logoColor=white'/></a>
2. Now deploy.
    <br>
    <a href='https://dashboard.heroku.com/new?template=https://github.com/boru-to/KATAKURI_MD' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-purple?style=for-the-badge&logo=heroku&logoColor=white'/></a>
### DEPLOY ON REPLIT
1. Deploy.
    <br>
    <a href='https://replit.com/github//boru-to/KATAKURI_MD target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Deploy-red?style=for-the-badge&logo=replit&logoColor=white'/></a>
### DEPLOY ON RAILWAY
1. Deploy.
    <br>
    <a href='https://railway.com/github//boru-to/KATAKURI_MD target="_blank"><img alt='Railway' src='https://img.shields.io/badge/-Deploy-green?style=for-the-badge&logo=railway&logoColor=white'/></a>

    <h2 align="center"> ⚠️ NOTE  </h2>
## KATAKURI_MD SCRIPT IS NOT OPENLY ALLOWED TO USED IN ANY OF YOUR PROJECTS BE WARNED!!! 

## ```Connect With Me```<img src="https://github.com/0xAbdulKhalid/0xAbdulKhalid/raw/main/assets/mdImages/handshake.gif" width ="80"></h1> 
 <br> 
<p align="center">
<a href="https://wa.me/27747815326"><img src="https://img.shields.io/badge/Contact katakuri-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="https://whatsapp.com/channel/0029Vaf5x0eHFxP7JvSRRn1g"><img src="https://img.shields.io/badge/Join Official Channel-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<p align="center">
<img alt="Development" width="250" src="https://media2.giphy.com/media/W9tBvzTXkQopi/giphy.gif?cid=6c09b952xu6syi1fyqfyc04wcfk0qvqe8fd7sop136zxfjyn&ep=v1_internal_gif_by_id&rid=giphy.gif&ct=g" /> </p>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
# 

<br>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

* [🧑‍💻 Follow KATAKURI Whatsapp Channel🧑‍💻](https://whatsapp.com/channel/0029Vaf5x0eHFxP7JvSRRn1g)

  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
  

- *KATAKURI_MD is not made by `WhatsApp Inc.` Sometimes or misusing the bot might `ban` your `WhatsApp account!`*
- *In that case, I'm not responsible for banning your account.*
- *Use KATAKURI_MD at your own risk by keeping this warning in mind.*
  
  #### ```katakuri PROFILE VIEWS 🧚```
![Visitor Count](https://profile-counter.glitch.me/boru-to/count.svg)

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


## Support

SUPPORT CHANNEL: <a href="[https://whatsapp.com/channel/0029Vaf5x0eHFxP7JvSRRn1g)"><img alt="WhatsApp" src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>


### Please Give One Star ✨ & [follow me notify my updates 💗](https://github.com/boru-to)
<b>Version -> 2.0.0</b>

## License
This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for more details.
 
 