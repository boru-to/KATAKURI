(function (_0x239ebe, _0x4c2d87) {
    const _0x47b6b3 = _0x4b8f, _0x4adba9 = _0x239ebe();
    while (!![]) {
        try {
            const _0x54e3c5 = -parseInt(_0x47b6b3(0x1f1)) / 0x1 + -parseInt(_0x47b6b3(0x1e6)) / 0x2 + -parseInt(_0x47b6b3(0x1ea)) / 0x3 + -parseInt(_0x47b6b3(0x1fc)) / 0x4 * (parseInt(_0x47b6b3(0x1e9)) / 0x5) + parseInt(_0x47b6b3(0x1ff)) / 0x6 * (parseInt(_0x47b6b3(0x1ec)) / 0x7) + parseInt(_0x47b6b3(0x1fa)) / 0x8 + -parseInt(_0x47b6b3(0x1f2)) / 0x9 * (-parseInt(_0x47b6b3(0x1f8)) / 0xa);
            if (_0x54e3c5 === _0x4c2d87)
                break;
            else
                _0x4adba9['push'](_0x4adba9['shift']());
        } catch (_0x5e0625) {
            _0x4adba9['push'](_0x4adba9['shift']());
        }
    }
}(_0x312b, 0x3124f));
const report = async (_0x15b3fd, _0x11ca7e) => {
    const _0x355305 = _0x4b8f, _0x1165e4 = {}, _0x35c59f = _0x355305(0x1fe), _0x47c010 = _0x15b3fd[_0x355305(0x203)][_0x355305(0x202)](/^[\\/!#.]/), _0x4b0604 = _0x47c010 ? _0x47c010[0x0] : '/', _0x26d121 = _0x15b3fd[_0x355305(0x203)]['startsWith'](_0x4b0604) ? _0x15b3fd[_0x355305(0x203)][_0x355305(0x1f3)](_0x4b0604['length'])[_0x355305(0x1ee)]('\x20')[0x0][_0x355305(0x1ed)]() : '', _0x2d4ff0 = _0x15b3fd[_0x355305(0x203)][_0x355305(0x1f3)](_0x4b0604['length'] + _0x26d121[_0x355305(0x1f9)])[_0x355305(0x1e7)](), _0x238ece = [
            _0x355305(0x1f7),
            'request'
        ];
    if (_0x238ece['includes'](_0x26d121)) {
        if (!_0x2d4ff0)
            return _0x15b3fd[_0x355305(0x1fd)](_0x355305(0x200) + _0x15b3fd['pushName'] + _0x355305(0x1f0) + (_0x4b0604 + _0x26d121) + _0x355305(0x1eb));
        const _0x32fddf = _0x15b3fd['key']['id'];
        if (_0x1165e4[_0x32fddf])
            return _0x15b3fd[_0x355305(0x1fd)](_0x355305(0x1f4));
        _0x1165e4[_0x32fddf] = !![];
        const _0x5e8cf7 = _0x355305(0x204), _0x19e1f0 = '\x0a\x0a*User*:\x20@' + _0x15b3fd[_0x355305(0x1fb)]['split']('@')[0x0] + _0x355305(0x1f5) + _0x2d4ff0, _0x1552d2 = _0x355305(0x1e8) + _0x15b3fd[_0x355305(0x201)] + _0x355305(0x1ef);
        _0x11ca7e['sendMessage'](_0x35c59f + _0x355305(0x1f6), {
            'text': _0x5e8cf7 + _0x19e1f0,
            'mentions': [_0x15b3fd[_0x355305(0x1fb)]]
        }, { 'quoted': _0x15b3fd }), _0x15b3fd[_0x355305(0x1fd)]('*Hello\x20_' + _0x15b3fd[_0x355305(0x201)] + '_*\x0aTʜᴀɴᴋ\x20ʏᴏᴜ\x20ꜰᴏʀ\x20ʏᴏᴜʀ\x20ʀᴇᴘᴏʀᴛ.\x0aIᴛ\x20ʜᴀs\x20ʙᴇᴇɴ\x20ꜰᴏʀᴡᴀʀᴅᴇᴅ\x20ᴛᴏ\x20ᴛʜᴇ\x20ᴏᴡɴᴇʀ.\x0aPʟᴇᴀsᴇ\x20ᴡᴀɪᴛ\x20ꜰᴏʀ\x20ᴀ\x20ʀᴇsᴘᴏɴsᴇ.');
    }
};
function _0x4b8f(_0x32926f, _0x434ea4) {
    const _0x312bac = _0x312b();
    return _0x4b8f = function (_0x4b8f05, _0x40620a) {
        _0x4b8f05 = _0x4b8f05 - 0x1e6;
        let _0x1696e0 = _0x312bac[_0x4b8f05];
        return _0x1696e0;
    }, _0x4b8f(_0x32926f, _0x434ea4);
}
function _0x312b() {
    const _0x4dc0ae = [
        'split',
        ',\x20your\x20request\x20has\x20been\x20forwarded\x20to\x20my\x20Owners.*\x0a*Please\x20wait...*',
        '_*\x0aUsage\x20Example:\x20',
        '204305QEFSma',
        '4016277PntBMT',
        'slice',
        'This\x20report\x20has\x20already\x20been\x20forwarded\x20to\x20the\x20owner.\x20Please\x20wait\x20for\x20a\x20response.',
        '\x0a*Request/Bug*:\x20',
        '@s.whatsapp.net',
        'report',
        '10KNMCUx',
        'length',
        '2666336kXglYJ',
        'sender',
        '481744cEHkHl',
        'reply',
        '254110853827',
        '107418QfJRkW',
        '*Hello\x20_',
        'pushName',
        'match',
        'body',
        '*|\x20REQUEST/BUG\x20|*',
        '67088KwbCTg',
        'trim',
        '\x0a\x0a*Hi\x20',
        '10woYSyI',
        '513423DbzSVe',
        '\x20hi\x20dev\x20play\x20command\x20is\x20not\x20working',
        '28cdPiNF',
        'toLowerCase'
    ];
    _0x312b = function () {
        return _0x4dc0ae;
    };
    return _0x312b();
}
export default report;
