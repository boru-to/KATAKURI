(function (_0xa6aff8, _0x395862) {
    const _0xed75c8 = _0x365c, _0x5021a0 = _0xa6aff8();
    while (!![]) {
        try {
            const _0x255896 = parseInt(_0xed75c8(0x1c1)) / 0x1 * (parseInt(_0xed75c8(0x1b9)) / 0x2) + -parseInt(_0xed75c8(0x1c4)) / 0x3 + parseInt(_0xed75c8(0x1bd)) / 0x4 + parseInt(_0xed75c8(0x1c3)) / 0x5 * (parseInt(_0xed75c8(0x1ba)) / 0x6) + -parseInt(_0xed75c8(0x1bb)) / 0x7 + parseInt(_0xed75c8(0x1c2)) / 0x8 + -parseInt(_0xed75c8(0x1c8)) / 0x9;
            if (_0x255896 === _0x395862)
                break;
            else
                _0x5021a0['push'](_0x5021a0['shift']());
        } catch (_0x3c1cc6) {
            _0x5021a0['push'](_0x5021a0['shift']());
        }
    }
}(_0x370e, 0xcd979));
function _0x365c(_0x32b485, _0x273d36) {
    const _0x370e19 = _0x370e();
    return _0x365c = function (_0x365c12, _0x3309ff) {
        _0x365c12 = _0x365c12 - 0x1b6;
        let _0x470922 = _0x370e19[_0x365c12];
        return _0x470922;
    }, _0x365c(_0x32b485, _0x273d36);
}
function _0x370e() {
    const _0x57b897 = [
        'exit',
        'pushName',
        'slice',
        '17617095gmsIKQ',
        'message',
        'match',
        'split',
        'An\x20error\x20occurred\x20while\x20restarting\x20the\x20bot:\x20',
        'error',
        'Hello\x20*_',
        '204312hkrwmT',
        '20964ZeGXZc',
        '997773rhCeWu',
        'body',
        '4081772DrRehS',
        'length',
        'toLowerCase',
        'reply',
        '9BgzcdJ',
        '6243744nAoSQb',
        '2355CsaJhr',
        '4271670jcWIBA'
    ];
    _0x370e = function () {
        return _0x57b897;
    };
    return _0x370e();
}
const rebootBot = async _0x5a36c4 => {
    const _0x5d238e = _0x365c, _0x316700 = _0x5a36c4['body'][_0x5d238e(0x1ca)](/^[\\/!#.]/), _0x5cff47 = _0x316700 ? _0x316700[0x0] : '/', _0x3cad8d = _0x5a36c4[_0x5d238e(0x1bc)]['startsWith'](_0x5cff47) ? _0x5a36c4['body'][_0x5d238e(0x1c7)](_0x5cff47[_0x5d238e(0x1be)])[_0x5d238e(0x1cb)]('\x20')[0x0][_0x5d238e(0x1bf)]() : '';
    if (_0x3cad8d === 'reboot')
        try {
            await _0x5a36c4[_0x5d238e(0x1c0)](_0x5d238e(0x1b8) + _0x5a36c4[_0x5d238e(0x1c6)] + '_,*\x0a\x20*Gifted-Md\x20is\x20Rebooting....*'), process[_0x5d238e(0x1c5)]();
        } catch (_0xf3a360) {
            return console[_0x5d238e(0x1b7)](_0xf3a360), await _0x5a36c4['React']('❌'), _0x5a36c4[_0x5d238e(0x1c0)](_0x5d238e(0x1b6) + _0xf3a360[_0x5d238e(0x1c9)]);
        }
};
export default rebootBot;
