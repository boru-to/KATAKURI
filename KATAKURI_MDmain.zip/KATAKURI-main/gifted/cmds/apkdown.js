(function (_0x2152d1, _0x2c2bda) {
    const _0x5f2fe3 = _0xd01e, _0xbc169e = _0x2152d1();
    while (!![]) {
        try {
            const _0x563296 = parseInt(_0x5f2fe3(0x104)) / (-0x1c21 * -0x1 + -0x3f2 * 0x6 + -0x14 * 0x39) + -parseInt(_0x5f2fe3(0x187)) / (-0x2301 + 0x71a * -0x3 + 0x3851) * (parseInt(_0x5f2fe3(0x10d)) / (0x1539 + 0x1624 + -0x2b5a)) + parseInt(_0x5f2fe3(0x17d)) / (-0x6 + 0x1274 + -0x126a) + parseInt(_0x5f2fe3(0x13f)) / (0x3a8 + -0x7c3 * -0x5 + -0x6 * 0x713) * (-parseInt(_0x5f2fe3(0x12e)) / (-0x1656 + 0x2518 * -0x1 + 0x3b74)) + parseInt(_0x5f2fe3(0x14c)) / (-0xb7b + -0x72 * 0x39 + 0x24e4) + -parseInt(_0x5f2fe3(0x167)) / (-0x1509 * -0x1 + 0xcf1 + -0x21f2) * (parseInt(_0x5f2fe3(0x15e)) / (-0x5fa * -0x1 + -0x2ce * -0x4 + -0xbf * 0x17)) + parseInt(_0x5f2fe3(0x12a)) / (0x9de + 0x1a * -0x94 + 0x534);
            if (_0x563296 === _0x2c2bda)
                break;
            else
                _0xbc169e['push'](_0xbc169e['shift']());
        } catch (_0x350a4a) {
            _0xbc169e['push'](_0xbc169e['shift']());
        }
    }
}(_0x5ade, 0x7bcac + -0x81ed1 * -0x3 + -0x123e33));
import {
    search,
    download
} from 'aptoide-scraper';
import _0x219438, { prepareWAMessageMedia } from 'gifted-baileys';
const {generateWAMessageFromContent, proto} = _0x219438, apkMap = new Map();
function _0xd01e(_0x1bc2af, _0x32efbb) {
    const _0x342980 = _0x5ade();
    return _0xd01e = function (_0x400dcc, _0x33e796) {
        _0x400dcc = _0x400dcc - (-0x1c3 * -0x10 + 0x2 * 0x811 + -0x2b58);
        let _0x1d73ed = _0x342980[_0x400dcc];
        return _0x1d73ed;
    }, _0xd01e(_0x1bc2af, _0x32efbb);
}
function _0x5ade() {
    const _0x182bec = [
        'dqHsx',
        'slice',
        'K:\x0a\x0aName:\x20',
        'ttonReplyM',
        '😎\x20Top\x2050\x20A',
        'arch\x20and\x20d',
        'error',
        '𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃\x20𝐕',
        'rch\x20query\x20',
        'map',
        'JrbTK',
        'waUploadTo',
        '15FKYiBf',
        'voljc',
        'Ioymr',
        'from',
        'No\x20APKs\x20fo',
        'Message',
        'set',
        'essage',
        'ByJtK',
        'e-archive',
        'all',
        '𝐀𝐏𝐊\x20𝐃𝐎𝐖𝐍𝐋𝐎',
        'trim',
        '2259943JfJkAe',
        'n/vnd.andr',
        'templateBu',
        'match',
        '📥\x20',
        'NQspp',
        '𝟓*',
        'size',
        'Size:\x20',
        'mply\x20selec',
        'GASus',
        'icon',
        'stringify',
        '\x20𝐕𝟓*',
        'st\x20below\x20t',
        'r\x20request.',
        'ect',
        '99b56.jpg',
        '110421SXIKwM',
        'includes',
        'https://te',
        'parse',
        'hsIhF',
        'fwHqV',
        'ɴ\x20ᴀᴘᴘ',
        'ted.\x0a\x0a',
        '\x0a\x0a>\x20*©𝟐𝟎𝟐𝟒',
        '648EjkvUG',
        '𝐀𝐃𝐄𝐑\x0a\x0a🔍\x20Se',
        't\x20an\x20APK\x20f',
        'You\x20select',
        'MygQI',
        'Server',
        'relayMessa',
        'apk_',
        'Please\x20pro',
        'ed\x20this\x20AP',
        'Pmwfz',
        'ing\x20APK:',
        'applicatio',
        'PIOvL',
        'create',
        '>\x20*©𝟐𝟎𝟐𝟒\x20𝐆',
        'NativeFlow',
        'aHyyq',
        'dllink',
        'length',
        'paramsJson',
        'rom\x20the\x20li',
        '2273164zhvzIe',
        '🤩\x20Top\x2050',
        'ownload\x20yo',
        'ily.\x0a\x0a📌\x20Si',
        'startsWith',
        'ac5fc11b31',
        'app',
        'und.',
        '\x20𝐆𝐈𝐅𝐓𝐄𝐃\x20𝐌𝐃',
        'vide\x20a\x20sea',
        '14FHvMOl',
        'searchapk',
        'TMtno',
        'get',
        'CbgvJ',
        'oid.packag',
        'Interactiv',
        'split',
        'hcUYs',
        'message',
        'single_sel',
        '992047vlSCfA',
        'remoteJid',
        'sendMessag',
        'ur\x20favorit',
        'name',
        'ing\x20APK.',
        'IYKbd',
        'for\x20APKs',
        'selectedId',
        '280218VlpNmm',
        'o\x20get\x20star',
        'lCvYK',
        'key',
        '\x0asize:\x20',
        'cNouo',
        'legra.ph/f',
        'nativeFlow',
        'Body',
        'apkdl',
        'apk',
        'body',
        'ResponseMe',
        'toLowerCas',
        'Footer',
        'eMessage',
        'ile/bf3a4c',
        'LeRyr',
        'Error\x20proc',
        'gqVAk',
        'r\x20request:',
        'e\x20APKs\x20eas',
        'ssage',
        'essing\x20you',
        'sender',
        'eResponseM',
        'hhxFU',
        '🔖\x20sᴇʟᴇᴄᴛ\x20ᴀ',
        'Error\x20send',
        '20170170EUrFTM',
        'Header',
        'interactiv',
        '𝐆𝐈𝐅𝐓𝐄𝐃-𝐌𝐃\x20',
        '2689122JjcPYq',
        '.apk',
        'reply',
        'React',
        'PK\x20Results'
    ];
    _0x5ade = function () {
        return _0x182bec;
    };
    return _0x5ade();
}
let apkIndex = 0x466 * 0x3 + -0xe14 + 0x1 * 0xe3;
const searchAPK = async (_0x1af83b, _0x399c11) => {
    const _0xf914c6 = _0xd01e, _0x25bbfb = {
            'gqVAk': function (_0x2acbfb, _0x59b182) {
                return _0x2acbfb + _0x59b182;
            },
            'Pmwfz': function (_0x5344b5, _0x49ef09) {
                return _0x5344b5(_0x49ef09);
            },
            'hcUYs': function (_0x325d88, _0x308b05) {
                return _0x325d88 || _0x308b05;
            },
            'dqHsx': _0xf914c6(0x117),
            'fwHqV': _0xf914c6(0xfa),
            'hhxFU': _0xf914c6(0x116),
            'NQspp': _0xf914c6(0x183),
            'LeRyr': _0xf914c6(0x16f) + _0xf914c6(0x186) + _0xf914c6(0x13b) + _0xf914c6(0x10b),
            'PIOvL': function (_0x2adc84, _0x468f4d) {
                return _0x2adc84 === _0x468f4d;
            },
            'IYKbd': _0xf914c6(0x143) + _0xf914c6(0x184),
            'MygQI': function (_0x134743, _0x4afe90, _0x56dda1, _0x260b1d) {
                return _0x134743(_0x4afe90, _0x56dda1, _0x260b1d);
            },
            'lCvYK': _0xf914c6(0x176) + _0xf914c6(0x13a) + _0xf914c6(0x152),
            'GASus': function (_0x13f591, _0x3b7f7c, _0x5efc9f) {
                return _0x13f591(_0x3b7f7c, _0x5efc9f);
            },
            'cNouo': _0xf914c6(0x103) + _0xf914c6(0x15c),
            'ByJtK': _0xf914c6(0x128) + _0xf914c6(0x164),
            'JrbTK': _0xf914c6(0x137) + _0xf914c6(0x132),
            'CbgvJ': _0xf914c6(0x17e),
            'aHyyq': _0xf914c6(0x11f) + _0xf914c6(0x124) + _0xf914c6(0x121),
            'TMtno': _0xf914c6(0x11f) + _0xf914c6(0x124) + _0xf914c6(0x15b),
            'Ioymr': _0xf914c6(0x173) + _0xf914c6(0x14d) + _0xf914c6(0xfe) + _0xf914c6(0x148),
            'hsIhF': _0xf914c6(0x129) + _0xf914c6(0x172),
            'voljc': _0xf914c6(0x129) + _0xf914c6(0x109)
        };
    let _0x30d37a;
    const _0x454ff4 = _0x1af83b?.[_0xf914c6(0x102)]?.[_0xf914c6(0x14e) + _0xf914c6(0x136) + _0xf914c6(0x146)]?.[_0xf914c6(0x10c)], _0x2f67cf = _0x1af83b?.[_0xf914c6(0x102)]?.[_0xf914c6(0x12c) + _0xf914c6(0x126) + _0xf914c6(0x146)];
    if (_0x2f67cf) {
        const _0x5989e2 = _0x2f67cf[_0xf914c6(0x114) + _0xf914c6(0x119) + _0xf914c6(0x123)]?.[_0xf914c6(0x17b)];
        if (_0x5989e2) {
            const _0x10478b = JSON[_0xf914c6(0x161)](_0x5989e2);
            _0x30d37a = _0x10478b['id'];
        }
    }
    const _0x5ea3b2 = _0x25bbfb[_0xf914c6(0x101)](_0x30d37a, _0x454ff4), _0x30df58 = _0x1af83b[_0xf914c6(0x118)][_0xf914c6(0x14f)](/^[\\/!#.]/), _0x1fee84 = _0x30df58 ? _0x30df58[0xed * 0x27 + -0x14 * 0x15d + -0x8d7] : '/', _0xdd1691 = _0x1af83b[_0xf914c6(0x118)][_0xf914c6(0x181)](_0x1fee84) ? _0x1af83b[_0xf914c6(0x118)][_0xf914c6(0x134)](_0x1fee84[_0xf914c6(0x17a)])[_0xf914c6(0x100)]('\x20')[-0x9 * -0x112 + 0x8c6 + -0x1268][_0xf914c6(0x11a) + 'e']() : '', _0x5015ac = _0x1af83b[_0xf914c6(0x118)][_0xf914c6(0x134)](_0x25bbfb[_0xf914c6(0x120)](_0x1fee84[_0xf914c6(0x17a)], _0xdd1691[_0xf914c6(0x17a)]))[_0xf914c6(0x14b)](), _0x34f5f1 = [
            _0x25bbfb[_0xf914c6(0x133)],
            _0x25bbfb[_0xf914c6(0x163)],
            _0x25bbfb[_0xf914c6(0x127)],
            _0x25bbfb[_0xf914c6(0x151)]
        ];
    if (_0x34f5f1[_0xf914c6(0x15f)](_0xdd1691)) {
        if (!_0x5015ac)
            return _0x1af83b[_0xf914c6(0x130)](_0x25bbfb[_0xf914c6(0x11e)]);
        try {
            await _0x1af83b[_0xf914c6(0x131)]('🕘');
            let _0x3dc589 = await _0x25bbfb[_0xf914c6(0x171)](search, _0x5015ac);
            const _0x2492d1 = _0x3dc589[_0xf914c6(0x134)](0x6e * 0xd + -0x1f98 + -0x2 * -0xd01, 0x1d27 + 0x26f * 0x1 + -0x1f64);
            if (_0x25bbfb[_0xf914c6(0x174)](_0x2492d1[_0xf914c6(0x17a)], 0x14f7 * -0x1 + 0x1b8e * 0x1 + -0x697)) {
                _0x1af83b[_0xf914c6(0x130)](_0x25bbfb[_0xf914c6(0x10a)]), await _0x1af83b[_0xf914c6(0x131)]('❌');
                return;
            }
            const _0x3d1545 = await Promise[_0xf914c6(0x149)](_0x2492d1[_0xf914c6(0x13c)](async (_0x4866f9, _0x15e2b6) => {
                    const _0x40647c = _0xf914c6, _0x4c54bc = _0x40647c(0x16e) + _0x25bbfb[_0x40647c(0x120)](apkIndex, _0x15e2b6), _0x87b55c = await _0x25bbfb[_0x40647c(0x171)](download, _0x4866f9['id']);
                    return apkMap[_0x40647c(0x145)](_0x4c54bc, {
                        ..._0x4866f9,
                        'size': _0x87b55c[_0x40647c(0x153)]
                    }), {
                        'header': '',
                        'title': _0x40647c(0x150) + _0x4866f9[_0x40647c(0x108)],
                        'description': _0x40647c(0x154) + _0x87b55c[_0x40647c(0x153)],
                        'id': _0x4c54bc
                    };
                })), _0x382194 = _0x25bbfb[_0xf914c6(0x16b)](generateWAMessageFromContent, _0x1af83b[_0xf914c6(0x142)], {
                    'viewOnceMessage': {
                        'message': {
                            'messageContextInfo': {
                                'deviceListMetadata': {},
                                'deviceListMetadataVersion': 0x2
                            },
                            'interactiveMessage': proto[_0xf914c6(0x144)][_0xf914c6(0xff) + _0xf914c6(0x11c)][_0xf914c6(0x175)]({
                                'body': proto[_0xf914c6(0x144)][_0xf914c6(0xff) + _0xf914c6(0x11c)][_0xf914c6(0x115)][_0xf914c6(0x175)]({ 'text': _0xf914c6(0x12d) + _0xf914c6(0x14a) + _0xf914c6(0x168) + _0xf914c6(0x138) + _0xf914c6(0x17f) + _0xf914c6(0x107) + _0xf914c6(0x122) + _0xf914c6(0x180) + _0xf914c6(0x155) + _0xf914c6(0x169) + _0xf914c6(0x17c) + _0xf914c6(0x15a) + _0xf914c6(0x10e) + _0xf914c6(0x165) }),
                                'footer': proto[_0xf914c6(0x144)][_0xf914c6(0xff) + _0xf914c6(0x11c)][_0xf914c6(0x11b)][_0xf914c6(0x175)]({ 'text': _0x25bbfb[_0xf914c6(0x10f)] }),
                                'header': proto[_0xf914c6(0x144)][_0xf914c6(0xff) + _0xf914c6(0x11c)][_0xf914c6(0x12b)][_0xf914c6(0x175)]({
                                    ...await _0x25bbfb[_0xf914c6(0x156)](prepareWAMessageMedia, { 'image': { 'url': _0xf914c6(0x160) + _0xf914c6(0x113) + _0xf914c6(0x11d) + _0xf914c6(0x182) + _0xf914c6(0x15d) } }, { 'upload': _0x399c11[_0xf914c6(0x13e) + _0xf914c6(0x16c)] }),
                                    'title': '',
                                    'gifPlayback': !![],
                                    'subtitle': '',
                                    'hasMediaAttachment': ![]
                                }),
                                'nativeFlowMessage': proto[_0xf914c6(0x144)][_0xf914c6(0xff) + _0xf914c6(0x11c)][_0xf914c6(0x177) + _0xf914c6(0x144)][_0xf914c6(0x175)]({
                                    'buttons': [{
                                            'name': _0x25bbfb[_0xf914c6(0x112)],
                                            'buttonParamsJson': JSON[_0xf914c6(0x158)]({
                                                'title': _0x25bbfb[_0xf914c6(0x147)],
                                                'sections': [{
                                                        'title': _0x25bbfb[_0xf914c6(0x13d)],
                                                        'highlight_label': _0x25bbfb[_0xf914c6(0xfd)],
                                                        'rows': _0x3d1545
                                                    }]
                                            })
                                        }]
                                }),
                                'contextInfo': {
                                    'mentionedJid': [_0x1af83b[_0xf914c6(0x125)]],
                                    'forwardingScore': 0x270f,
                                    'isForwarded': ![]
                                }
                            })
                        }
                    }
                }, {});
            await _0x399c11[_0xf914c6(0x16d) + 'ge'](_0x382194[_0xf914c6(0x110)][_0xf914c6(0x105)], _0x382194[_0xf914c6(0x102)], { 'messageId': _0x382194[_0xf914c6(0x110)]['id'] }), await _0x1af83b[_0xf914c6(0x131)]('✅'), apkIndex += _0x2492d1[_0xf914c6(0x17a)];
        } catch (_0x105c2a) {
            console[_0xf914c6(0x139)](_0x25bbfb[_0xf914c6(0x178)], _0x105c2a), _0x1af83b[_0xf914c6(0x130)](_0x25bbfb[_0xf914c6(0xfb)]), await _0x1af83b[_0xf914c6(0x131)]('❌');
        }
    } else {
        if (_0x5ea3b2) {
            const _0x126238 = apkMap[_0xf914c6(0xfc)](_0x5ea3b2);
            if (_0x126238)
                try {
                    const _0x143c7e = await _0x25bbfb[_0xf914c6(0x171)](download, _0x126238['id']), _0x1447c6 = _0x143c7e[_0xf914c6(0x179)], _0x1abc20 = _0x143c7e[_0xf914c6(0x157)], _0x3ef05c = _0x143c7e[_0xf914c6(0x153)];
                    await _0x399c11[_0xf914c6(0x106) + 'e'](_0x1af83b[_0xf914c6(0x142)], {
                        'image': { 'url': _0x1abc20 },
                        'caption': _0xf914c6(0x16a) + _0xf914c6(0x170) + _0xf914c6(0x135) + _0x126238[_0xf914c6(0x108)] + _0xf914c6(0x111) + _0x3ef05c + (_0xf914c6(0x166) + _0xf914c6(0x185) + _0xf914c6(0x159))
                    }, { 'quoted': _0x1af83b });
                    const _0x26f46a = {
                        'document': { 'url': _0x1447c6 },
                        'mimetype': _0x25bbfb[_0xf914c6(0x141)],
                        'fileName': _0x126238[_0xf914c6(0x108)] + _0xf914c6(0x12f)
                    };
                    await _0x399c11[_0xf914c6(0x106) + 'e'](_0x1af83b[_0xf914c6(0x142)], _0x26f46a, { 'quoted': _0x1af83b });
                } catch (_0x3c08ee) {
                    console[_0xf914c6(0x139)](_0x25bbfb[_0xf914c6(0x162)], _0x3c08ee), _0x1af83b[_0xf914c6(0x130)](_0x25bbfb[_0xf914c6(0x140)]);
                }
            else {
            }
        }
    }
};
export default searchAPK;
